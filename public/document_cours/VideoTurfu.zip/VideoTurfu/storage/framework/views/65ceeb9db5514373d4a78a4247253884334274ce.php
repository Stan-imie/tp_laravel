

<?php $__env->startSection('title', $movie['title']); ?>

<?php $__env->startSection('content'); ?>
    <article class="row">
        <div class="col-6">
            <header>
                <h1><?php echo e($movie['title']); ?></h1>
                <ul>
                    <li><small>Catégories : <?php echo e($movie['categories']); ?></small></li>
                    <li><small>Réalisateur : <?php echo e($movie['director']); ?></small></li>
                    <li><small>Date de sortie : <?php echo e($movie['date']); ?></small></li>
                </ul>
            </header>
            <p>
                <button class="btn btn-info">Acheter</button>
            </p>
            <h2>Synopsis :</h2>
            <p><?php echo e($movie['synopsis']); ?></p>
        </div>
        <div class="col-6">
            <img src="<?php echo e(asset('img/'.$movie['img_affiche'])); ?>" class="img-fluid">
        </div>
    </article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/c/Users/micka/Documents/Sites/VideoTurfu/resources/views/video/view.blade.php ENDPATH**/ ?>