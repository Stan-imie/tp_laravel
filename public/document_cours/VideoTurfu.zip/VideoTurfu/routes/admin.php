<?php

Route::get('/', 'MainController@index')
    ->name('index');