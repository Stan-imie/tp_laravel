<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TotoController extends Controller
{
    public function bonjour($prenom="tout le monde")
    {
        if ($prenom == "toto") {
            return response()->redirectToRoute('bonjour', ['prenom'=>'titi']);
        } else {
            return 'Bonjour '.$prenom;
        }
    }

    public function bonjourDeux($prenom, $nom)
    {
        return 'Rebonjour '.$prenom.' '.$nom;
    }
}
